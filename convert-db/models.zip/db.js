const mongoose = require('mongoose')
const book = require('./models/book')
const readline = require('readline')
    , fs = require('fs');

(async function run() {
    mongoose.connect('mongodb+srv://nam:clay71715@ror-v0rxn.mongodb.net/test?retryWrites=true&w=majority', { useNewUrlParser: true, poolSize: 300 })
    try {
        let arr = []
        const rl = readline.createInterface({
            input: fs.createReadStream('book-cv.json')
        })
        rl.on('line', (line) => {
            line = JSON.parse(line)
            arr.push(new book({
                _id: new mongoose.Types.ObjectId().toHexString(),
                title: line.title,
                titleWords: line.titleWords,
                shortContent: line.shortContent,
                shortContentWords: line.shortContentWords,
                content: line.content,
                excerpt: line.excerpt,
                authors: line.authors,
                writers: line.writers,
                tags: line.tags,
                size: line.size,
                publisher: line.publisher,
                published: line.published,
                categories: line.categories,
                pages: line.pages,
                language: line.language,
                formats: line.formats
            }))
            console.log(arr)
        })
        await rl.once('close', () => {
            book.insertMany(arr).then((result) => {
                console.log('upload done!')
            }).catch(err => console.log(err))
        })
    } catch (err) {
        console.log(err)
    }
})()